/****************************************************************************
 ** Interface for running and viewing analyses for the One Line application.
 **
 ** @license
 ** Copyright (c) 2019 Xendee Corporation. All rights reserved.
 ***************************************************************************/
import App from '../one-line/app.js'
import utils from './utils.js'
import constants from './constants.js'
import messages, { getMessage } from './messages.js'
import ModalTemplate from './modal-template.js'
import Glide, { Controls, Breakpoints } from '../glide.modular.esm.js'

export default class Analyses {
  constructor(app) {
    this.app = app
    this.getCompletedAnalysesDataUrl = `${constants.API_PATH}/${constants.RESOURCES.GET_COMPLETED_ANALYSES}/${window.oneLineProjectId}`
    this.getAvailableAnalysesDataUrl = `${constants.API_PATH}/${constants.RESOURCES.GET_AVAILABLE_ANALYSES}?projectTypeId=`
    this.postRunAnalysisDataUrl = `${constants.API_PATH}/${constants.RESOURCES.POST_RUN_ANALYSIS}/${window.oneLineProjectId}`
    this.getAnalysisReportDataUrl = `${constants.API_PATH}/${constants.RESOURCES.GET_ANALYSIS_REPORT}/${window.oneLineProjectId}?analysisId=`
    this.getDownloadAnalysisResultsDataUrl = `${constants.API_PATH}/${constants.RESOURCES.GET_DOWNLOAD_ANALYSIS_RESULTS}/${window.oneLineProjectId}?analysisId=`
    this.patchAnalysisSettingsDataUrl = `${constants.API_PATH}/${constants.RESOURCES.UPDATE_ANALYSIS_SETTINGS}/${window.oneLineProjectId}?analysisId=`

    this.wizard = null                              // Wizard for new analyses
    this.currentAnalysisId = null                   // Analysis ID of the currently-selected row in the Completed Analyses table
    this.currentDownloadUrl = null
    this.currentStudyName = null
    this.animationDuration = 500
    this.completedAnalysesDataTable = null
    this.availableAnalysesContext = []
    this.availableAnalysesDataTable
    this.selectedAnalyticProviderAnalyticId = null  // Keep track of which analysis engine is currently selected
    this.runAnalysisDataTable
    this.runAnalysisData                            // POST request data for RunAnalysis
    this.runAnalysisChecked = false
    this.runAnalysisErrors = null
    this.analysisCatalogDataTable
    this.settingsRequestBody = null
  }

  get projectTypeId() { return this._projectTypeId }
  set projectTypeId(value) { this._projectTypeId = value }

  main() {
    this.getCompletedAnalyses()
  }

  getCompletedAnalyses() {
    this.app.synchronousFetcher.get(this.getCompletedAnalysesDataUrl).then(response => {
      console.log('Analyses.getCompletedAnalyses()::response', response)
      
      if (response.status === 200) {
        this.onGetCompletedAnalysesSuccess(response)
      } else
        this.onGetCompletedAnalysesError(response)

      return response

    }).catch(error => {
      this.onGetCompletedAnalysesFailure(error)
      return error
    })
  }

  removeCompletedAnalyses() {
    document.getElementById(constants.SELECTORS.ANALYSES_HOME_MODAL).remove()
  }

  onGetCompletedAnalysesSuccess(response) {
    const templateName = constants.TEMPLATE_NAMES.ANALYSES_HOME
    const templateType = constants.MODAL_CATEGORIES.ACTION
    const context = {
      data: {}
    }
    context.data.modalName = constants.MODALS.ANALYSES
    context.data.completedAnalyses = response.data
    context.reportUrl = this.getAnalysisReportDataUrl
    context.settingsUrl = this.getAnalysisSettingsDataUrl
    context.downloadUrl = this.getDownloadAnalysisResultsDataUrl

    this.completedAnalysesModalTemplate = new ModalTemplate(templateName, templateType, context)
    this.completedAnalysesModalTemplate.prepareContext()
    console.log('Analyses.onGetCompletedAnalysesSuccess::context', context)
    this.completedAnalysesModalTemplate.execute()

    this.applyCompletedAnalysesDataTable()
    this.addCancelButtonListener()
    this.addNewAnalysisButtonListener()
    this.addBackToOneLineButtonListener()
    this.addDownloadReportLinkListeners()
    this.addAnalysisSettingsLinkListeners()
    this.addBackAnnotationLinkListeners()
    this.addDownloadDataLinkListeners()

    this.app.printingOverlay.resetPrintOverlay()

    this.wizard = new Glide('.glide', { animationDuration: this.animationDuration }).mount({ Controls, Breakpoints })
    this.addWizardEventListener()
    this.hideWizardBullets()

    return response
  }

  onGetCompletedAnalysesError(response) {
    this.app.notification.showError(response.data.message)
    return response
  }

  onGetCompletedAnalysesFailure(error) {
    this.app.notification.showError(messages.SERVER_ERROR)
    console.error(error)
    return error
  }

  addWizardEventListener() {
    this.wizard.on('run', () => {
      if (this.wizard.index === 0) {
        this.hideWizardBullets()
        this.availableAnalysesDataTable.destroy()
        utils.emptyInnerHTML(
          constants.SELECTORS.ANALYSES_NEW_PANEL,
          constants.SELECTORS.ANALYSIS_OPTIONS_PANEL,
          `${constants.SELECTORS.ANALYSIS_ERROR_PANEL} ${constants.SELECTORS.ERROR_GRID_BODY}`
        )
      }
      else this.showWizardBullets()
    })
  }
  
  hideWizardBullets() {
    utils.hide(constants.SELECTORS.GLIDE_BULLETS)
    utils.hide(constants.SELECTORS.STEP_LABELS)
    utils.hide(constants.SELECTORS.ADD_NEW_ANALYSIS_HEADER)
  }

  showWizardBullets() {
    utils.show(constants.SELECTORS.GLIDE_BULLETS)
    utils.show(constants.SELECTORS.STEP_LABELS)
    utils.show(constants.SELECTORS.ADD_NEW_ANALYSIS_HEADER)
  }

  applyCompletedAnalysesDataTable() {
    if (!this.completedAnalysesDataTable) {
      this.completedAnalysesDataTable = jQuery(constants.SELECTORS.COMPLETED_ANALYSES_TABLE).DataTable({
        paging: false,
        searching: false,
        scrollCollapse: true,
        scrollY: "280px",
        scrollX: true,
        order: [
          [5, "desc"]
        ],
        columnDefs: [
          { orderable: false, targets: [0, 1, 2, 3] }
        ]
      })
      this.completedAnalysesDataTable.columns.adjust().draw()
    }
  }

  addCancelButtonListener() {
    const closeButtons = document.querySelectorAll(`#${constants.MODALS_BY_TYPE.ANALYSES[0]} ${constants.SELECTORS.CLOSE_BUTTON}`)
    for (const closeButton of closeButtons) {
        closeButton.addEventListener('click', () => this.completedAnalysesModalTemplate.destroyModal())
    }
  }

  addDownloadReportLinkListeners() {
    utils.addEventListenerByClass(constants.SELECTORS.DOWNLOAD_REPORT_LINK, 'click', (event) => {
      this.getReport(event)
    })
  }

  addAnalysisSettingsLinkListeners() {
    utils.addEventListenerByClass(constants.SELECTORS.ANALYSIS_SETTINGS_LINK, 'click', (event) => {
      this.getAnalysisSettings(event)
    })
  }

  addBackAnnotationLinkListeners() {
    utils.addEventListenerByClass(constants.SELECTORS.BACK_ANNOTATION_LINK, 'click', (event) => {
      this.app.showBackAnnotationGraph(event)
    })
  }

  addDownloadDataLinkListeners() {
    utils.addEventListenerByClass(constants.SELECTORS.DOWNLOAD_DATA_LINK, 'click', (event) => {
      this.getReportData(event)
    })
  }

  addNewAnalysisButtonListener() {
    const newAnalysisButton = document.querySelector(constants.SELECTORS.NEW_ANALYSIS_BUTTON)
    utils.addEvent(newAnalysisButton, 'click', () => this.getAvailableAnalyses())
  }

  addBackToOneLineButtonListener() {
    const backToOneLineButton = document.querySelector(constants.SELECTORS.ANALYSIS_BACK_TO_ONE_LINE_BUTTON)
    utils.addEvent(backToOneLineButton, 'click', () => {
      if (App.ShowingAnalysisOneLine) {
        this.app.showMainGraph()
      }
    })
  }

  getAnalysisSettings() {
    this.currentAnalysisId = event.target.closest('tr').getAttribute('data-analysis-id')

    this.app.synchronousFetcher.get(`${this.app.getAnalysisDataUrl}${this.currentAnalysisId}`).then(response => {
      console.log('Analyses.getAnalysisSettings()::response', response)

      if (response.status === 200)
        this.onGetAnalysisSettingsSuccess(response)
      else
        this.onGetAnalysisSettingsError(response)

    }).catch(error => {
      this.onGetAnalysisSettingsFailure(error)
    })
  }

  onGetAnalysisSettingsSuccess(response) {
    const templateName = constants.TEMPLATE_NAMES.POWER_FLOW_ANALYSIS_SETTINGS
    const templateType = constants.MODAL_CATEGORIES.ACTION
    const context = {
      data: {
        modalName: constants.MODALS.POWER_FLOW_ANALYSIS_SETTINGS,
        ...response.data
      }
    }

    this.analysisSettingsTemplate = new ModalTemplate(templateName, templateType, context)
    this.analysisSettingsTemplate.prepareContext()
    this.analysisSettingsTemplate.execute(null, true, true, false)

    this.initializeSaveSettingsButton()
    this.initializeCloseSettingsButtons()
    return response
  }

  onGetAnalysisSettingsError(response) {
    this.app.notification.showError(response.data.message)
    return response
  }

  onGetAnalysisSettingsFailure(error) {
    this.app.notification.showError(messages.SERVER_ERROR)
    console.error(error)
    return error
  }
  
  initializeSaveSettingsButton() {
    const saveButton = document.querySelector(`${constants.SELECTORS.POWER_FLOW_ANALYSIS_SETTINGS_MODAL} ${constants.SELECTORS.SAVE_BUTTON}`)
    utils.addEvent(saveButton, 'click', () => this.submitAnalysisSettingsForm())
  }

  initializeCloseSettingsButtons() {
    utils.addEventListenerByClass(constants.SELECTORS.DESTROY_BUTTON, 'click', () => {
      this.analysisSettingsTemplate.destroyModal()
    })
  }

  submitAnalysisSettingsForm() {
    this.settingsRequestBody = this.generateAnalysisSettingsRequest()
    console.log('Analyses.submitAnalysisSettingsForm()::this.settingsRequestBody', this.settingsRequestBody)
    this.patchAnalysisSettings()
  }

  getReport(event) {
    this.app.notification.showProgressMessage(`<p><i class="fas fa-spinner fa-spin fa-lg" aria-hidden="true"></i><div class="text-center">Preparing report... One moment...</div></p>`)
    this.currentReportUrl = event.target.closest('td').getAttribute('data-report-url')
    this.currentStudyName = event.target.closest('tr').getAttribute('data-study-name')

    this.app.synchronousFetcher({
      url: `${this.currentReportUrl}`,
      method: 'GET',
      responseType: 'blob'
    }).then(response => {
      console.log('Analyses.getReport()::response', response)
      if (response.status === 200)
        this.onGetReportSuccess(response)
      else
        this.onGetReportError(response)
    }).catch(error =>
      this.onGetReportFailure(error)
    )
  }

  onGetReportSuccess(response) {
    setTimeout(() => {
      const blob = new Blob([response.data])
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `${this.currentStudyName}.pdf`)
      utils.simulateClick(document.querySelector('.noty_close_button'))
      link.click()
      window.URL.revokeObjectURL(blob)
    }, 1000)
  }

  onGetReportError(response) {
    this.app.notification.showError(response.data.message)
    return response
  }

  onGetReportFailure(error) {
    this.app.notification.showError(messages.SERVER_ERROR)
    console.error(error)
    return error
  }

  getReportData(event) {
    this.app.notification.showProgressMessage(`<p><i class="fas fa-spinner fa-spin fa-lg" aria-hidden="true"></i><div class="text-center">Preparing download... One moment...</div></p>`)
    this.currentDownloadUrl = event.target.closest('td').getAttribute('data-download-url')
    this.currentStudyName = event.target.closest('tr').getAttribute('data-study-name')

    this.app.synchronousFetcher({
      url: `${this.currentDownloadUrl}`,
      method: 'GET',
      responseType: 'blob'
    }).then(response => {
      console.log('Analyses.getReport()::response', response)
      if (response.status === 200)
        this.onGetReportDataSuccess(response)
      else
        this.onGetReportDataError(response)
    }).catch(error =>
      this.onGetReportDataFailure(error)
    )
  }

  onGetReportDataSuccess(response) {
    setTimeout(() => {
      const blob = new Blob([response.data])
      const url = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.setAttribute('download', `${this.currentStudyName}.zip`)
      utils.simulateClick(document.querySelector('.noty_close_button'))
      link.click()
      window.URL.revokeObjectURL(blob)
    }, 1500)
  }

  onGetReportDataError(response) {
    this.app.notification.showError(response.data.message)
    return response
  }

  onGetReportDataFailure(error) {
    this.app.notification.showError(messages.SERVER_ERROR)
    console.error(error)
    return error
  }

  generateAnalysisSettingsRequest() {
    return [
      { id: constants.ANALYSIS_OPTIONS.BUS_UNDER_LOADED_UPPERBOUND, value: utils.forms.getHiddenFieldValue('under-loaded-upperbound') },
      { id: constants.ANALYSIS_OPTIONS.BUS_UNDER_LOADED_COLOR, value: this.getHexColorOrDefault('under-loaded') },
      { id: constants.ANALYSIS_OPTIONS.BUS_NORMAL_LOADED_UPPERBOUND, value: utils.forms.getHiddenFieldValue('normal-loaded-upperbound') },
      { id: constants.ANALYSIS_OPTIONS.BUS_NORMAL_LOADED_COLOR, value: this.getHexColorOrDefault('normal') },
      { id: constants.ANALYSIS_OPTIONS.BUS_FULLY_LOADED_UPPERBOUND, value: utils.forms.getHiddenFieldValue('fully-loaded-upperbound') },
      { id: constants.ANALYSIS_OPTIONS.BUS_FULLY_LOADED_COLOR, value: this.getHexColorOrDefault('fully-loaded') },
      { id: constants.ANALYSIS_OPTIONS.BUS_OVER_LOADED_COLOR, value: this.getHexColorOrDefault('over-loaded') },
      { id: constants.ANALYSIS_OPTIONS.BUS_UNDER_VOLTAGE_UPPERBOUND, value: utils.forms.getHiddenFieldValue('under-voltage-upperbound') },
      { id: constants.ANALYSIS_OPTIONS.BUS_UNDER_VOLTAGE_COLOR, value: this.getHexColorOrDefault('under-voltage') },
      { id: constants.ANALYSIS_OPTIONS.BUS_NORMAL_VOLTAGE_UPPERBOUND, value: utils.forms.getHiddenFieldValue('normal-voltage-upperbound') },
      { id: constants.ANALYSIS_OPTIONS.BUS_NORMAL_VOLTAGE_COLOR, value: this.getHexColorOrDefault('normal-voltage') },
      { id: constants.ANALYSIS_OPTIONS.BUS_OVER_VOLTAGE_COLOR, value: this.getHexColorOrDefault('over-voltage') },
      { id: constants.ANALYSIS_OPTIONS.ANNOTATE_NAME, value: utils.forms.getBooleanFieldValue('annotation-name') },
      { id: constants.ANALYSIS_OPTIONS.ANNOTATE_DESCRIPTION, value: utils.forms.getBooleanFieldValue('annotation-description') },
      { id: constants.ANALYSIS_OPTIONS.ANNOTATE_CATALOG_NAME, value: utils.forms.getBooleanFieldValue('annotation-catalog-name') },
      { id: constants.ANALYSIS_OPTIONS.ANNOTATE_VOLTAGE, value: utils.forms.getBooleanFieldValue('annotation-nominal-voltage') },
      { id: constants.ANALYSIS_OPTIONS.ANNOTATE_PERCENT_LOADED, value: utils.forms.getBooleanFieldValue('annotation-percent-loaded') },
      { id: constants.ANALYSIS_OPTIONS.ANNOTATE_PERCENT_VOLTAGE_DROP, value: utils.forms.getBooleanFieldValue('annotation-percent-voltage-drop') },
      { id: constants.ANALYSIS_OPTIONS.ANNOTATE_CALC_CURRENT, value: utils.forms.getBooleanFieldValue('annotation-current') },
      { id: constants.ANALYSIS_OPTIONS.ANNOTATE_CALC_VOLTAGE, value: utils.forms.getBooleanFieldValue('annotation-voltage') },
      { id: constants.ANALYSIS_OPTIONS.ANNOTATE_RATED_POWER, value: utils.forms.getBooleanFieldValue('annotation-rated-power') },
      { id: constants.ANALYSIS_OPTIONS.ANNOTATE_PU, value: utils.forms.getBooleanFieldValue('annotation-voltage-pu') }
    ]
  }

  getHexColorOrDefault(formField) {
    return utils.forms.getSelectFieldValue(formField) || '000000' // Server wants a default of black
  }

  patchAnalysisSettings() {
    this.app.synchronousFetcher.patch(`${this.patchAnalysisSettingsDataUrl}${this.currentAnalysisId}`, this.settingsRequestBody).then(response => {
      console.log('Analyses.getAvailableAnalyses()::response', response)
      if (response.data.success)
        this.onPatchAnalysisSettingsSuccess(response)
      else
        this.onPatchAnalysisSettingsError(response)

    }).catch(error => {
      this.onPatchAnalysisSettingsFailure(error)
    })
  }

  onPatchAnalysisSettingsSuccess(response) {
    this.app.showMainGraph()
    this.analysisSettingsTemplate.destroyModal()

    this.app.projectElementsChanged(false, false, false)

    App.Project.updateLastModifiedDate()
    this.app.notification.showSuccess(messages.SAVE_ANALYSIS_SETTINGS_SUCCESS)
  }

  onPatchAnalysisSettingsError(response) {
    this.app.notification.showError(messages.SAVE_ANALYSIS_SETTINGS_ERROR)
  }

  onPatchAnalysisSettingsFailure(error) {
    this.app.notification.showError(messages.SAVE_ANALYSIS_SETTINGS_ERROR)
    console.error(error)
  }

  getAvailableAnalyses() {
    this.app.synchronousFetcher.get(`${this.getAvailableAnalysesDataUrl}${constants.PROJECT_TYPE_IDS.INDUSTRIAL_BALANCED}`).then(response => {
      console.log('Analyses.getAvailableAnalyses()::response', response)
      
      if (response.status === 200)
        this.onGetAvailableAnalysesSuccess(response, false)
      else
        this.onGetAvailableAnalysesError(response)

    }).catch(error => {
      this.onGetAvailableAnalysesFailure(error)
    })
  }

  onGetAvailableAnalysesSuccess(response) {
    const templateName = constants.TEMPLATE_NAMES.ANALYSES_NEW
    const templateType = constants.MODAL_CATEGORIES.ACTION
    const context = {
      data: {
        modalName: constants.MODALS.ANALYSES_NEW,
        availableAnalyses: response.data
      }
    }

    this.newAnalysisModalTemplate = new ModalTemplate(templateName, templateType, context)
    this.newAnalysisModalTemplate.prepareContext()
    console.log('Analyses.onGetAvailableAnalysesSuccess::context', context)
    this.availableAnalysesContext = context.data.availableAnalyses
    this.newAnalysisModalTemplate.execute(constants.SELECTORS.ANALYSES_NEW_PANEL, false)
    this.selectedAnalyticProviderAnalyticId = null
    this.applyAvailableAnalysesDataTable()
    this.initializeRowListener()
    this.addSelectOptionsButtonListener()
    this.addCancelButtonListener()
    this.addCancelAnalysisButtonListener()
    utils.show(constants.SELECTORS.GLIDE_BULLETS)
    this.wizard.go('>')
    return response
  }

  onGetAvailableAnalysesError(response) {
    this.app.notification.showError(response.data.message)
    return response
  }

  onGetAvailableAnalysesFailure(error) {
    this.app.notification.showError(messages.SERVER_ERROR)
    console.error(error)
    return error
  }

  applyAvailableAnalysesDataTable() {
    this.availableAnalysesDataTable = jQuery(constants.SELECTORS.AVAILABLE_ANALYSES_TABLE).DataTable({
      paging: false,
      searching: false,
      scrollCollapse: true,
      scrollY: "350px",
      scrollX: true,
      order: [
        [0, "asc"]
      ],
      select: {
        style: 'single'
      }
    })
    this.availableAnalysesDataTable.columns.adjust().draw()
  }

  initializeRowListener() {
    utils.delegateEvent('tbody tr', 'click', (mouseEvent) => {
      const tableRow = mouseEvent.target.closest('tr')
      this.selectedAnalyticProviderAnalyticId = tableRow.getAttribute(constants.SELECTORS.DATA_ANALYTIC_PROVIDER_ANALYTIC_ID)
      this.showAvailableAnalysisDetails()
    }, constants.SELECTORS.AVAILABLE_ANALYSES_TABLE)
  }

  showAvailableAnalysisDetails() {
    const detailsContainer = document.querySelector(constants.SELECTORS.AVAILABLE_ANALYSIS_DETAILS)
    const templateName = constants.TEMPLATE_NAMES.ANALYSIS_DETAILS
    const templateType = constants.MODAL_CATEGORIES.ACTION
    const selectedAnalysisDetails =
        this.availableAnalysesContext.find(x => x.AnalyticProviderAnalyticId === Number(this.selectedAnalyticProviderAnalyticId))
    const context = {
      data: {
        modalName: constants.MODALS.ANALYSIS_DETAILS,
        details: selectedAnalysisDetails
      }
    }
    
    this.analysisDetailsModalTemplate = new ModalTemplate(templateName, templateType, context)
    this.analysisDetailsModalTemplate.prepareContext()

    console.log('Analyses.showAvailableAnalysisDetails()::context', context)
    detailsContainer.innerHTML = ''
    this.analysisDetailsModalTemplate.execute(constants.SELECTORS.AVAILABLE_ANALYSIS_DETAILS, false, true)

    this.addSelectOptionsButtonListener()
  }

  addSelectOptionsButtonListener() {
    const selectOptionsButtonWrapper = document.getElementById(constants.SELECTORS.SELECT_OPTIONS_BUTTON_WRAPPER)
    let selectOptionsButton = document.querySelector(constants.SELECTORS.SELECT_OPTIONS_BUTTON)

    selectOptionsButtonWrapper.innerHTML = selectOptionsButtonWrapper.innerHTML
    selectOptionsButton = document.querySelector(constants.SELECTORS.SELECT_OPTIONS_BUTTON)
    selectOptionsButton.addEventListener('click', this.renderAndGoToAnalysisOptions.bind(this))
  }

  renderAndGoToAnalysisOptions(event) {
    event.preventDefault()
    if (this.selectedAnalyticProviderAnalyticId === null)
      this.app.notification.showImportantMessage(messages.ANALYSES_MISSING_ENGINE)
    else if (this.selectedAnalyticProviderAnalyticId !== '2001')
      this.app.notification.showImportantMessage(messages.ANALYSES_ONLY_POWER_FLOW)
    else {
      this.renderAnalysisOptions()
      this.wizard.go('>')
    }
  }

  addCancelAnalysisButtonListener() {
    const cancelAnalysisButton = document.querySelector(constants.SELECTORS.CANCEL_ANALYSIS_BUTTON)
    utils.addEvent(cancelAnalysisButton, 'click', (event) => {
      event.preventDefault()
      this.selectedAnalyticProviderAnalyticId = null
      this.wizard.go('<')
    })
  }

  renderAnalysisOptions() {
    const templateName = constants.TEMPLATE_NAMES.ANALYSES_OPTIONS
    const templateType = constants.MODAL_CATEGORIES.ACTION
    const powerProducers = Array.from(App.Project.getPowerProducers()).map(item => {
      item.meta = {
        nodeType: constants.LABELS[item.NodeType],
        converted: {
          voltage: utils.formatUnitValue(item.Details.Voltage, constants.UNITS.V, true),
          threePhaseShortCircuit: utils.formatUnitValue(item.Details.ThreePhaseShortCircuit, constants.UNITS.kVA, true)
        }
      }
      return item
    })
    const context = {
      data: {
        modalName: constants.MODALS.ANALYSES_OPTIONS, 
        powerProducers,
        analysisType: document.getElementById(constants.SELECTORS.ANALYSIS_TITLE).innerText
      }
    }

    this.analysesOptionsModalTemplate = new ModalTemplate(templateName, templateType, context)
    this.analysesOptionsModalTemplate.prepareContext()
    this.analysesOptionsModalTemplate.execute(constants.SELECTORS.ANALYSIS_OPTIONS_PANEL, false)
    this.applyAnalysisCatalogDataTable()
    this.updateStudyName()

    this.addCancelOptionsButtonListener()
    this.addCloseOptionsButtonListener()
    this.addSelectCatalogRowListener()
    this.addRunButtonListener()

    // If there's only one power producer, simulate a click on the row
    // If there are multiple power producers, don't select any -- unless there is a single UTILITY in that group
    if (context.data.powerProducers.length === 1)
      utils.simulateClick(document.querySelector(`${constants.SELECTORS.ANALYSIS_CATALOG_TABLE} ${constants.SELECTORS.FIRST_ROW_FIRST_CELL}`))
    else {
      const utilities = context.data.powerProducers.filter(x => x.NodeType === constants.NODE_TYPES.UTILITY)
      if (utilities.length === 1)
        utils.simulateClick(document.querySelector(`[data-catalog-node-id="${utilities[0].NodeId}"] td:nth-child(1)`))
    }
  }

  applyAnalysisCatalogDataTable() {
    this.analysisCatalogDataTable = jQuery(constants.SELECTORS.ANALYSIS_CATALOG_TABLE).DataTable({
      paging: false,
      searching: false,
      scrollCollapse: true,
      scrollY: "500px",
      scrollX: true,
      order: [
        [0, "asc"]
      ],
      select: {
        style: 'single'
      },
      destroy: true
    })
    this.analysisCatalogDataTable.columns.adjust().draw()
  }

  addCancelOptionsButtonListener() {
    const cancelButtons = document.querySelectorAll(constants.SELECTORS.CANCEL_ANALYSIS_OPTIONS_BUTTON)
    for (const cancelButton of cancelButtons) {
      const cancelAnalysisOptionsPanel = () => {
        setTimeout(() => {
          this.analysisCatalogDataTable && this.analysisCatalogDataTable.destroy()
          utils.emptyInnerHTML(constants.SELECTORS.ANALYSIS_OPTIONS_PANEL)
          delete this.analysisCatalogDataTable
          utils.removeEvent(cancelButton, 'click', cancelAnalysisOptionsPanel)
        }, this.animationDuration)
        this.wizard.go('<<')
      }
      utils.addEvent(cancelButton, 'click', cancelAnalysisOptionsPanel)
    }
  }

  addCloseOptionsButtonListener() {
    const closeButtons = document.querySelectorAll(constants.SELECTORS.DESTROY_ANALYSIS_OPTIONS_BUTTON)
    for (const closeButton of closeButtons) {
      const destroyAnalysisOptionsPanel = () => {
        this.wizard.go('<')
        this.analysisCatalogDataTable && this.analysisCatalogDataTable.destroy()
        utils.emptyInnerHTML(constants.SELECTORS.ANALYSIS_OPTIONS_PANEL)
        delete this.analysisCatalogDataTable
        utils.removeEvent(closeButton, 'click', destroyAnalysisOptionsPanel)
      }
      utils.addEvent(closeButton, 'click', destroyAnalysisOptionsPanel)
    }
    this.addSelectOptionsButtonListener()
  }

  addSelectCatalogRowListener() {
    const rows = document.querySelectorAll(`${constants.SELECTORS.ANALYSIS_CATALOG_TABLE} tbody tr`)
    for (const row of rows) {
      const setRunState = () => {
        this.updateEquipmentName()
        this.setRunState()
        document.querySelector(constants.SELECTORS.RUN_ANALYSIS_BUTTON).removeAttribute('disabled')
      }
      utils.addEvent(row, 'click', setRunState)
    }
  }

  addRunButtonListener() {
    const runButton = document.querySelector(constants.SELECTORS.RUN_ANALYSIS_BUTTON)
    const postRunAnalysis = () => {
      this.setRunState()
      this.validateRunState(() => {
        this.wizard.go('>>')
        utils.showBlockingSpinner()
        this.postRunAnalysis()
      })
    }
    utils.addEvent(runButton, 'click', postRunAnalysis)
  }

  validateRunState(successCallback) {
    if (!this.runAnalysisData.StudyData || !this.runAnalysisData.AnalyticTypeId) {
      this.app.notification.showError(messages.ANALYSES_MISSING_SWING_BUS)
      return
    } else if (!this.runAnalysisData.StudyName) {
      this.app.notification.showError(messages.ANALYSES_MISSING_STUDY_NAME)
      return
    }
    successCallback()
  }

  updateEquipmentName() {
    document.getElementById(constants.SELECTORS.EQUIPMENT_NAME).innerText = event.target.parentNode.querySelector(`td:nth-child(1)`).innerText
  }

  updateStudyName() {
    document.getElementById(constants.SELECTORS.STUDY_NAME).value = `${document.getElementById(constants.SELECTORS.ANALYSIS_TITLE).innerText} study`
  }

  setRunState() {
    const selectedAnalysisRow = document.querySelector(`${constants.SELECTORS.AVAILABLE_ANALYSES_TABLE} tr.selected`)
    this.runAnalysisData = {
      AnalyticTypeId: Number(selectedAnalysisRow.getAttribute(constants.SELECTORS.DATA_ANALYTIC_PROVIDER_ANALYTIC_ID)),
      StudyName: document.getElementById(constants.SELECTORS.STUDY_NAME).value,
      StudyNotes: document.getElementById(constants.SELECTORS.STUDY_NOTES).value || null,
      StudyData: document.getElementById(constants.SELECTORS.EQUIPMENT_NAME).innerText
    }
    if (this.runAnalysisChecked)
      this.runAnalysisData.RunWithWarnings = true
    else
      this.runAnalysisData.RunWithWarnings = false

    console.table(this.runAnalysisData)
  }

  postRunAnalysis() {
    console.log('Analyses.postRunAnalysis()::request', this.runAnalysisData)

    this.app.synchronousFetcher.post(this.postRunAnalysisDataUrl, this.runAnalysisData).then(response => {
      console.log('Analyses.postRunAnalysis()::response', response)
      setTimeout(() => {
        if (response.data)
          this.onPostRunAnalysisSuccess(response)
        else
          this.onPostRunAnalysisError(response)
        utils.hideBlockingSpinner()
      }, 1000)
    }).catch(error => {
      this.onPostRunAnalysisFailure(error)
    })
  }
  
  onPostRunAnalysisSuccess(response) {
    //const analysisChecked = this.runAnalysisChecked

    // A server error involving a failed analysis
    if (utils.isString(response.data)) {
      response.data = utils.removeSpecialChars(response.data)
      response.data = JSON.parse(response.data)
      if (!response.data.success) {
        this.app.notification.showError(response.data.message)
        console.error('Analyses.onPostRunAnalysisSuccess()::response', 'A DSS error occurred.', response)
      }
      this.runAnalysisChecked = false

    // Warnings and/or errors to display in a grid
    } else if (Array.isArray(response.data) && response.data.length > 0) {
      this.setAnalysisErrorState(response.data)
      this.runAnalysisChecked = true
      this.renderAnalysisErrors()
      this.addFixLinkListeners()

      // Ensure no event listeners stack up in the button row
      document.querySelector(constants.SELECTORS.ANALYSES_ERRORS_CONTENT_BUTTON_ROW).innerHTML =
          document.querySelector(constants.SELECTORS.ANALYSES_ERRORS_CONTENT_BUTTON_ROW).innerHTML
      this.addCancelOptionsButtonListener()
      this.addDestroyErrorGridButtonListener()
      this.addRunAgainButtonListener()
      this.wizard.go('>>')

    // Analysis ran OK. Show sticky success message, update completed list, slide back to the beginning, and reset wizard views
    } else {
      this.wizard.go('>>')
      this.completedAnalysesDataTable.destroy()
      this.completedAnalysesDataTable = null
      this.app.notification.showImportantMessage(`<strong>${this.runAnalysisData.StudyName}</strong> was validated and saved successfully.`, () => {
        this.removeCompletedAnalyses()
        this.getCompletedAnalyses()
        this.wizard.go('<<')
        this.runAnalysisChecked = false
      })
    }

    console.log('Analyses.onPostRunAnalysisSuccess()::response', response)
  }

  setAnalysisErrorState(data) {
    this.runAnalysisErrors = data
  }

  renderAnalysisErrors() {

    // Remove any existing table rows
    Array.from(
      document.querySelectorAll('.general-warning-row, .general-error-row, .warning-row, .error-row')
    ).forEach(x => x.remove())


    if (this.runAnalysisErrors.length > 0) {

      // Generate table rows
      this.errorMarkup = this.runAnalysisErrors.map((item, i) => {
        let tableRow
        if (item.IsWarning && item.AssociatedProjectElementId === null) {
          tableRow = `
            <tr class="general-warning-row">
              <td class="icon-cell"><i class="fal fa-exclamation-circle fa-2x"></i></td>
              <td>${item.Message}</td>
              <td></td>
            </tr>
          `
        } else if (!item.IsWarning && item.AssociatedProjectElementId === null) {
          tableRow = `
            <tr class="general-error-row">
              <td class="icon-cell"><i class="fal fa-skull-crossbones fa-2x"></i></td>
              <td>${item.Message}</td>
              <td></td>
            </tr>
          `
        } else if (item.IsWarning) {
          tableRow = `
            <tr class="warning-row" data-equipment-id="${item.AssociatedProjectElementId}">
              <td class="icon-cell"><i class="fal fa-exclamation-circle fa-2x"></i></td>
              <td>${item.Message}</td>
              <td><a class="fix-link" href="javascript:;" tooltip="Fix">Fix</a></td>
            </tr>
          `
        } else if (!item.IsWarning) {
          tableRow = `
            <tr class="error-row" data-equipment-id="${item.AssociatedProjectElementId}">
              <td class="icon-cell"><i class="fal fa-skull-crossbones fa-2x"></i></td>
              <td>${item.Message}</td>
              <td><a class="fix-link" href="javascript:;" tooltip="Fix">Fix</a></td>
            </tr>
          `
        }
        return tableRow
      })

      console.log('Analyses.renderAnalysisErrors()::this.errorMarkup', this.errorMarkup)

      // Append rows to error-grid table
      document.querySelector(`#analysis-errors-panel ${constants.SELECTORS.ERROR_GRID_BODY}`).innerHTML = this.errorMarkup.join("\n")

      // Show table and label and Run Again button
      utils.show('.table-title, .error-grid')
      document.querySelector(constants.SELECTORS.RUN_AGAIN_BUTTON).style.display = 'inline'
    
    } else {
      console.log('Analyses.renderAnalysisErrors()', 'No errors or warnings to render')
    }

  }

  addFixLinkListeners() {
    utils.addEventListenerByClass('fix-link', 'click', (event) => {
      const equipmentId = event.target.closest('tr').getAttribute('data-equipment-id')

      // Pop open the right branch/node modal
      const oneLineEquipmentItem = App.Project.getOneLineNode(equipmentId) || App.Project.getOneLineBranch(equipmentId)
      this.app.SelectedProjectElement = oneLineEquipmentItem
      this.app.editSelectedItem()
      utils.simulateClick(document.querySelector('.modal.fade.show .loadMore'))

      // Delete error grid rows that have this equipment ID
      this.deleteErrorGridRows(equipmentId)
      this.hideEmptyTable()
    })
  }

  addDestroyErrorGridButtonListener() {
    const destroyErrorGridButton = document.querySelector(constants.SELECTORS.DESTROY_ERROR_GRID_BUTTON)
    const destroyErrorGridEntries = () => {
      this.wizard.go('<')
      setTimeout(() => {
        utils.emptyInnerHTML(constants.SELECTORS.ERROR_GRID_BODY)
        utils.removeEvent(destroyErrorGridButton, 'click', destroyErrorGridEntries)
      }, 500)
    }
    utils.addEvent(destroyErrorGridButton, 'click', destroyErrorGridEntries)
  }

  addRunAgainButtonListener() {
    const runButton = document.querySelector(constants.SELECTORS.RUN_AGAIN_BUTTON)
    const postRunAnalysis = () => {
      this.setRunState()
      this.validateRunState(() => {
        utils.showBlockingSpinner()
        this.postRunAnalysis()
      })
    }
    runButton.removeEventListener('click', postRunAnalysis)
    runButton.addEventListener('click', postRunAnalysis, { once: true })
  }

  deleteErrorGridRows(equipmentId)  {
    const rowsToDelete = document.querySelectorAll(`[data-equipment-id="${equipmentId}"]`)
    Array.from(rowsToDelete).forEach(row => {
      utils.fadeOut(row, 250, 10, () => {
        row.remove()
      })
    })
  }
  
  hideEmptyTable() {
    if (document.querySelectorAll(`${constants.SELECTORS.ERROR_GRID_BODY} tr`).length === 0) {
      utils.hide(constants.SELECTORS.ERROR_GRID)
    }
  }

  onPostRunAnalysisError(response) {
    this.app.notification.showError(response.data.message)
  }

  onPostRunAnalysisFailure(error) {
    console.error('Analyses.onPostRunAnalysisFailure()::error', error)
    this.app.notification.showError(messages.SERVER_ERROR)
  }
}
